Config                            	= {}
Config.TackleDistance				= 4.0