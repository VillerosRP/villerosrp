------------------------------------------
--	iEnsomatic RealisticVehicleFailure  --
------------------------------------------
--
--	Created by Jens Sandalgaard
--
--	This work is licensed under a Creative Commons Attribution-ShareAlike 4.0 International License.
--
--	https://github.com/iEns/RealisticVehicleFailure
--


-- Configuration:

-- IIMPORTANTE: Alguns desses valores DEVEM ser definidos como um número de ponto flutuante. ie. 10.0 em vez de 10

cfg = {
	deformationMultiplier = 2.0,				-- Quanto o veículo deve se deformar visualmente de uma colisão? Faixa de 0,0 a 10,0 Onde 0,0 não é deformação e 10,0 é 10x deformação. -1 = não toque. Danos visuais não sincronizam bem com outros jogadores.
	deformationExponent = 0.4,					-- Quanto a configuração de deformação do arquivo de manipulação deve ser compactada em direção a 1.0. (Faça carros mais semelhantes). Um valor de 1 = sem alteração. Valores mais baixos irão comprimir mais, valores acima de 1 serão expandidos. Não defina a zero ou negativo.
	collisionDamageExponent = 0.6,				-- Quanto a configuração de deformação do arquivo de manipulação deve ser compactada em direção a 1.0. (Faça carros mais semelhantes). Um valor de 1 = sem alteração. Valores mais baixos irão comprimir mais, valores acima de 1 serão expandidos. Não defina a zero ou negativo.

	damageFactorEngine = 3.0,					-- Os valores são de 1 a 100. Valores mais altos significam mais danos ao veículo. Um bom ponto de partida é 10
	damageFactorBody = 3.0,					    -- Os valores são de 1 a 100. Valores mais altos significam mais danos ao veículo. Um bom ponto de partida é 10
	damageFactorPetrolTank = 64.0,				-- Os valores são de 1 a 200. Valores mais altos significam mais danos ao veículo. Um bom ponto de partida é 64
	engineDamageExponent = 0.6,					-- Quanto a configuração do dano do mecanismo de manipulação de arquivos deve ser compactada em direção a 1.0. (Faça carros mais semelhantes). Um valor de 1 = sem alteração. Valores mais baixos irão comprimir mais, valores acima de 1 serão expandidos. Não defina a zero ou negativo.
	weaponsDamageMultiplier = 0.01,				-- Quanto dano o veículo deve receber do fogo das armas. Faixa de 0,0 a 10,0, onde 0,0 não é dano e 10,0 é 10x dano. -1 = não toque
	degradingHealthSpeedFactor = 10,			-- Velocidade de degradação lenta da saúde, mas não falha. O valor de 10 significa que levará cerca de 0,25 segundo por ponto de integridade, portanto, a degradação de 800 a 305 levará cerca de 2 minutos de direção limpa. Valores mais altos significam degradação mais rápida
	cascadingFailureSpeedFactor = 8.0,			-- Os valores são de 1 a 100. Quando a saúde do veículo cai abaixo de um certo ponto, a falha em cascata se instala e a saúde cai rapidamente até o veículo morrer. Valores mais altos significam falha mais rápida. Um bom ponto de partida é 8

	degradingFailureThreshold = 800.0,			-- Abaixo desse valor, a lenta degradação da saúde será
	cascadingFailureThreshold = 360.0,			-- Abaixo desse valor, a falha em cascata de integridade será definida
	engineSafeGuard = 100.0,					-- Valor final da falha Coloque-o muito alto e o veículo não fume quando estiver desativado. Ajuste muito baixo, e o carro pegará fogo de uma única bala para o motor. Na saúde 100 um carro típico pode levar 3-4 balas para o motor antes de pegar fogo.

	torqueMultiplierEnabled = true,				-- Diminuir o torque do motor conforme o motor fica mais e mais danificado

	limpMode = false,							-- Se for verdade, o motor nunca falha completamente, assim você sempre será capaz de chegar a um mecânico a menos que você vire seu veículo e impeça que VehicleFlip esteja definido como verdadeiro.
	limpModeMultiplier = 0.15,					-- O multiplicador de torque a ser usado quando o veículo estiver mancando. Os valores são de 0,05 a 0,25

	preventVehicleFlip = false,					-- Se for verdade, você não pode virar um veículo de cabeça para baixo

	sundayDriver = true,						-- Se for verdade, a resposta do acelerador é dimensionada para permitir uma condução lenta e fácil. Não impedirá o acelerador total. Não funciona com aceleradores binários como um teclado. Defina como false para desativar. O recurso de parar sem reverter e manter a luz de freio também funciona para teclados.
	sundayDriverAcceleratorCurve = 7.5,			-- A curva de resposta para aplicar ao acelerador. Faixa de 0,0 a 10,0. Valores mais altos facilitam a condução lenta, o que significa que é necessária mais pressão no acelerador para acelerar. Não faz nada para os drivers de teclado
	sundayDriverBrakeCurve = 5.0,				-- A curva de resposta para aplicar ao freio. Faixa de 0,0 a 10,0. Valores mais altos permitem uma frenagem mais fácil, o que significa que mais pressão no acelerador é necessária para frear com força. Não faz nada para os drivers de teclado

	displayBlips = false,						-- Mostrar blips para locais de mecânica

	compatibilityMode = false,					-- impede que outros scripts modifiquem a integridade do tanque de combustível para evitar uma falha aleatória do motor com o BVA 2.01 (a desvantagem é a prevenção contra explosão)

	randomTireBurstInterval = 0,				-- Número de minutos (estatisticamente, não precisamente) para dirigir acima de 22 mph antes de obter uma perfuração do pneu. 0 = recurso desativado


	-- Classe Multiplicador Damagefator
	-- O fator de dano do motor, do corpo e do Petroltank será multiplicado por este valor, dependendo da classe do veículo.
	-- Use-o para aumentar ou diminuir o dano de cada classe

	classDamageMultiplier = {
		[0] = 	1.0,		--	0: Compacts
				1.0,		--	1: Sedans
				1.0,		--	2: SUVs
				1.0,		--	3: Coupes
				1.0,		--	4: Muscle
				1.0,		--	5: Sports Classics
				1.0,		--	6: Sports
				1.0,		--	7: Super
				0.25,		--	8: Motorcycles
				0.7,		--	9: Off-road
				0.25,		--	10: Industrial
				1.0,		--	11: Utility
				1.0,		--	12: Vans
				1.0,		--	13: Cycles
				0.5,		--	14: Boats
				1.0,		--	15: Helicopters
				1.0,		--	16: Planes
				1.0,		--	17: Service
				0.75,		--	18: Emergency
				0.75,		--	19: Military
				1.0,		--	20: Commercial
				1.0			--	21: Trains
	}
}



--[[

	-- Alternate configuration values provided by ImDylan93 - Vehicles can take more damage before failure, and the balance between vehicles has been tweaked.
	-- To use: comment out the settings above, and uncomment this section.

cfg = {

	deformationMultiplier = -1,					-- How much should the vehicle visually deform from a collision. Range 0.0 to 10.0 Where 0.0 is no deformation and 10.0 is 10x deformation. -1 = Don't touch
	deformationExponent = 1.0,					-- How much should the handling file deformation setting be compressed toward 1.0. (Make cars more similar). A value of 1=no change. Lower values will compress more, values above 1 it will expand. Dont set to zero or negative.
	collisionDamageExponent = 1.0,				-- How much should the handling file deformation setting be compressed toward 1.0. (Make cars more similar). A value of 1=no change. Lower values will compress more, values above 1 it will expand. Dont set to zero or negative.

	damageFactorEngine = 5.1,					-- Sane values are 1 to 100. Higher values means more damage to vehicle. A good starting point is 10
	damageFactorBody = 5.1,						-- Sane values are 1 to 100. Higher values means more damage to vehicle. A good starting point is 10
	damageFactorPetrolTank = 61.0,				-- Sane values are 1 to 100. Higher values means more damage to vehicle. A good starting point is 64
	engineDamageExponent = 1.0,					-- How much should the handling file engine damage setting be compressed toward 1.0. (Make cars more similar). A value of 1=no change. Lower values will compress more, values above 1 it will expand. Dont set to zero or negative.
	weaponsDamageMultiplier = 0.124,			-- How much damage should the vehicle get from weapons fire. Range 0.0 to 10.0, where 0.0 is no damage and 10.0 is 10x damage. -1 = don't touch
	degradingHealthSpeedFactor = 7.4,			-- Speed of slowly degrading health, but not failure. Value of 10 means that it will take about 0.25 second per health point, so degradation from 800 to 305 will take about 2 minutes of clean driving. Higher values means faster degradation
	cascadingFailureSpeedFactor = 1.5,			-- Sane values are 1 to 100. When vehicle health drops below a certain point, cascading failure sets in, and the health drops rapidly until the vehicle dies. Higher values means faster failure. A good starting point is 8

	degradingFailureThreshold = 677.0,			-- Below this value, slow health degradation will set in
	cascadingFailureThreshold = 310.0,			-- Below this value, health cascading failure will set in
	engineSafeGuard = 100.0,					-- Final failure value. Set it too high, and the vehicle won't smoke when disabled. Set too low, and the car will catch fire from a single bullet to the engine. At health 100 a typical car can take 3-4 bullets to the engine before catching fire.

	torqueMultiplierEnabled = true,				-- Decrease engine torge as engine gets more and more damaged

	limpMode = false,							-- If true, the engine never fails completely, so you will always be able to get to a mechanic unless you flip your vehicle and preventVehicleFlip is set to true
	limpModeMultiplier = 0.15,					-- The torque multiplier to use when vehicle is limping. Sane values are 0.05 to 0.25

	preventVehicleFlip = true,					-- If true, you can't turn over an upside down vehicle

	sundayDriver = true,						-- If true, the accelerator response is scaled to enable easy slow driving. Will not prevent full throttle. Does not work with binary accelerators like a keyboard. Set to false to disable. The included stop-without-reversing and brake-light-hold feature does also work for keyboards.
	sundayDriverAcceleratorCurve = 7.5,			-- The response curve to apply to the accelerator. Range 0.0 to 10.0. Higher values enables easier slow driving, meaning more pressure on the throttle is required to accelerate forward. Does nothing for keyboard drivers
	sundayDriverBrakeCurve = 5.0,				-- The response curve to apply to the Brake. Range 0.0 to 10.0. Higher values enables easier braking, meaning more pressure on the throttle is required to brake hard. Does nothing for keyboard drivers

	displayBlips = true,						-- Show blips for mechanics locations

	classDamageMultiplier = {
		[0] = 	1.0,		--	0: Compacts
				1.0,		--	1: Sedans
				1.0,		--	2: SUVs
				0.95,		--	3: Coupes
				1.0,		--	4: Muscle
				0.95,		--	5: Sports Classics
				0.95,		--	6: Sports
				0.95,		--	7: Super
				0.27,		--	8: Motorcycles
				0.7,		--	9: Off-road
				0.25,		--	10: Industrial
				0.35,		--	11: Utility
				0.85,		--	12: Vans
				1.0,		--	13: Cycles
				0.4,		--	14: Boats
				0.7,		--	15: Helicopters
				0.7,		--	16: Planes
				0.75,		--	17: Service
				0.85,		--	18: Emergency
				0.67,		--	19: Military
				0.43,		--	20: Commercial
				1.0			--	21: Trains
	}
}

]]--





-- End of Main Configuration

-- Configure Repair system

-- id=446 for wrench icon, id=72 for spraycan icon

repairCfg = {
	mechanics = {
	--[[
		{name="Mechanic", id=446, r=25.0, x=-337.0,  y=-135.0,  z=39.0},	-- LSC Burton
		{name="Mechanic", id=446, r=25.0, x=-1155.0, y=-2007.0, z=13.0},	-- LSC by airport
		{name="Mechanic", id=446, r=25.0, x=734.0,   y=-1085.0, z=22.0},	-- LSC La Mesa
		{name="Mechanic", id=446, r=25.0, x=1177.0,  y=2640.0,  z=37.0},	-- LSC Harmony
		{name="Mechanic", id=446, r=25.0, x=108.0,   y=6624.0,  z=31.0},	-- LSC Paleto Bay
		{name="Mechanic", id=446, r=18.0, x=538.0,   y=-183.0,  z=54.0},	-- Mechanic Hawic
		{name="Mechanic", id=446, r=15.0, x=1774.0,  y=3333.0,  z=41.0},	-- Mechanic Sandy Shores Airfield
		{name="Mechanic", id=446, r=15.0, x=1143.0,  y=-776.0,  z=57.0},	-- Mechanic Mirror Park
		{name="Mechanic", id=446, r=30.0, x=2508.0,  y=4103.0,  z=38.0},	-- Mechanic East Joshua Rd.
		{name="Mechanic", id=446, r=16.0, x=2006.0,  y=3792.0,  z=32.0},	-- Mechanic Sandy Shores gas station
		{name="Mechanic", id=446, r=25.0, x=484.0,   y=-1316.0, z=29.0},	-- Hayes Auto, Little Bighorn Ave.
		{name="Mechanic", id=446, r=33.0, x=-1419.0, y=-450.0,  z=36.0},	-- Hayes Auto Body Shop, Del Perro
		{name="Mechanic", id=446, r=33.0, x=268.0,   y=-1810.0, z=27.0},	-- Hayes Auto Body Shop, Davis
	--	{name="Mechanic", id=446, r=24.0, x=288.0,   y=-1730.0, z=29.0},	-- Hayes Auto, Rancho (Disabled, looks like a warehouse for the Davis branch)
		{name="Mechanic", id=446, r=27.0, x=1915.0,  y=3729.0,  z=32.0},	-- Otto's Auto Parts, Sandy Shores
		{name="Mechanic", id=446, r=45.0, x=-29.0,   y=-1665.0, z=29.0},	-- Mosley Auto Service, Strawberry
		{name="Mechanic", id=446, r=44.0, x=-212.0,  y=-1378.0, z=31.0},	-- Glass Heroes, Strawberry
		{name="Mechanic", id=446, r=33.0, x=258.0,   y=2594.0,  z=44.0},	-- Mechanic Harmony
		{name="Mechanic", id=446, r=18.0, x=-32.0,   y=-1090.0, z=26.0},	-- Simeons
		{name="Mechanic", id=446, r=25.0, x=-211.0,  y=-1325.0, z=31.0},	-- Bennys
		{name="Mechanic", id=446, r=25.0, x=903.0,   y=3563.0,  z=34.0},	-- Auto Repair, Grand Senora Desert
		{name="Mechanic", id=446, r=25.0, x=437.0,   y=3568.0,  z=38.0}		-- Auto Shop, Grand Senora Desert
	]]--	
	},

	fixMessages = {
		"Usted coloca el tapón de aceite de nuevo",
		"Usted paró la fuga de aceite usando goma de mascar",
		"Usted reparó el tubo de aceite con la cinta adhesiva",
		"Usted apretó el tornillo de la olla de aceite y paró el goteo",
		"Usted pateó el motor y mágicamente volvió a la vida",
		"Usted ha eliminado alguna herrumbre del tubo de chispa",
		"Usted gritó con su vehículo y de alguna manera tuvo un efecto"
	},
	fixMessageCount = 7,

	noFixMessages = {
		"Usted ha comprobado el tapón de aceite. Todavía está allí",
		"Usted miró a su motor, parecía bien",
		"Usted se asegura de que la cinta todavía estaba sosteniendo el motor",
		"Usted ha aumentado el volumen de la radio. Sólo sofocó los ruidos extraños del motor",
		"Usted ha agregado un anti-roya al tubo de chispa. No hacía diferencia",
		"Nunca conserte algo que no esteja quebrado, eles disseram. Você não escutou. Pelo menos não piorou"
	},
	noFixMessageCount = 6
}

RepairEveryoneWhitelisted = true
RepairWhitelist =
{
	"steam:123456789012345",
	"steam:000000000000000",
	"ip:192.168.0.1"			-- not sure if ip whitelist works?
}
