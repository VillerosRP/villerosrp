Citizen.CreateThread(function()
	for i = 1, 13 do
		EnableDispatchService(i, EnableDispatch)
	end
	while true do
		-- These natives has to be called every frame.
		SetVehicleDensityMultiplierThisFrame((TrafficAmount/25)+.0)
		SetPedDensityMultiplierThisFrame((PedestrianAmount/25)+.0)
		SetRandomVehicleDensityMultiplierThisFrame((TrafficAmount/25)+.0)
		SetParkedVehicleDensityMultiplierThisFrame((ParkedAmount/25)+.0)
		SetScenarioPedDensityMultiplierThisFrame((PedestrianAmount/25)+.0, (PedestrianAmount/25)+.0)
		Citizen.Wait(0)
	end
end)
