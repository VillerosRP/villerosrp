Config                            = {}
Config.DrawDistance               = 100.0
Config.MarkerType                 = 1
Config.MarkerSize                 = { x = 1.5, y = 1.5, z = 1.0 }
Config.MarkerColor                = { r = 50, g = 50, b = 204 }
Config.EnablePlayerManagement     = true
Config.EnableArmoryManagement     = true
Config.EnableESXIdentity          = true -- only turn this on if you are using esx_identity
Config.EnableNonFreemodePeds      = false -- turn this on if you want custom peds
Config.EnableSocietyOwnedVehicles = false
Config.EnableLicenses             = false
Config.MaxInService               = -1
Config.Locale                     = 'en'

Config.famaStations = {

  fama = {

    Blip = {
      Pos     = { x = 425.130, y = -979.558, z = 30.711 },
      Sprite  = 60,
      Display = 4,
      Scale   = 1.2,
      Colour  = 29,
    },

    AuthorizedWeapons = {
      { name = 'WEAPON_COMBATPISTOL',     price = 17000 },
      { name = 'WEAPON_FLARE',            price = 3000 },
      { name = 'WEAPON_SWITCHBLADE',      price = 8000 },
	  
    },

	  AuthorizedVehicles = {
		  { name = 'boxville2',  label = 'Camion recluta' },
	  },

    Cloakrooms = {
      { x = 553.23, y = 4546.97, z = 90.85 },
    },

    Armories = {
      { x = -791.23, y = -200.44, z = 37.617 },
    },

    Vehicles = {
      {
        Spawner    = { x = -793.66, y = -190.64, z = 37.25 },
        SpawnPoint = { x = -785.33, y = -187.33, z = 37.26 },
        Heading    = 90.0,
      }
    },
	
	Helicopters = {
      {
        Spawner    = { x = 2427.01, y = 4984.3, z = 46.627 },
        SpawnPoint = { x = 2435.21, y = 4988.85, z = 46.2 },
        Heading    = 0.0,
      }
    },

    VehicleDeleters = {
      { x = -775.7, y = -192.95, z = 37.15 },
    },

    BossActions = {
      { x = -813.16, y = -192.33, z = 41.66 }
    },

  },

}
