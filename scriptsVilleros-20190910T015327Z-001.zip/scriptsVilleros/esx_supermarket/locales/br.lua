Locales['br'] = {
  ['shop'] = 'Comprar',
  ['shops'] = 'Tiendas',
  ['press_menu'] = 'Apreta ~INPUT_CONTEXT~ para entrar a la tienda',
  ['shop_item'] = '$%s',
  ['bought'] = 'acabas de comprar ~y~%sx~s~ ~b~%s~s~ por ~r~$%s~s~',
  ['not_enough'] = 'No tenes ~r~guita suficiente~s~: %s',
  ['player_cannot_hold'] = 'Tenes el inventario lleno!',
  ['shop_confirm'] = 'Compro %sx %s por $%s?',
  ['no'] = 'No',
  ['yes'] = 'Si',
}
