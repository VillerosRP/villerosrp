Config = {}
 
Config.Animations = {

    {
        name  = 'greetings',
        label = 'Saludos y rapidas',
        items = {
		{label = "Usar telefono", type = "scenario", data = {anim = "WORLD_HUMAN_STAND_MOBILE_UPRIGHT"}},----------
        {label = "Sacar libreta", type = "scenario", data = {anim = "WORLD_HUMAN_CLIPBOARD"}},		
        {label = "Hacer una foto", type = "scenario", data = {anim = "WORLD_HUMAN_PAPARAZZI"}},
        {label = "De rodillas manos en la cabeza", type = "anim", data = {lib = "random@arrests@busted", anim = "idle_c"}},		
        {label = "Dar la mano", type = "anim", data = {lib = "mp_common", anim = "givetake1_a"}},
		{label = "Brazos Cruzados", type = "scenario", data = {anim = "WORLD_HUMAN_HANG_OUT_STREET"}},	
        {label = "Apoyarse en la pared", type = "scenario", data = {anim = "world_human_leaning"}},
		{label = "Limpiar", type = "scenario", data = {anim = "WORLD_HUMAN_MAID_CLEAN"}},		
		{label = "Mirar en el suelo", type = "scenario", data = {anim = "CODE_HUMAN_MEDIC_KNEEL"}},		
        {label = "Dar licencia de conducir", type = "anim", data = {lib = "oddjobs@taxi@cyi", anim = "std_hand_off_ps_passenger"}},		
		{label = "Liando", type = "scenario", data = {anim = "WORLD_HUMAN_BUM_STANDING"}},------- gan	
		{label = "Fumar peta", type = "scenario", data = {anim = "WORLD_HUMAN_DRUG_DEALER"}},
        {label = "Saludar", type = "anim", data = {lib = "gestures@m@standing@casual", anim = "gesture_hello"}},
        {label = "Apreton de manos", type = "anim", data = {lib = "mp_ped_interaction", anim = "handshake_guy_a"}},
        {label = "Saludo gangster", type = "anim", data = {lib = "mp_ped_interaction", anim = "hugs_guy_a"}},
        {label = "Saludo militar", type = "anim", data = {lib = "mp_player_int_uppersalute", anim = "mp_player_int_salute"}},
        }
    },

	{
        name  = 'festives',
        label = 'Festivas',
        items = {
        {label = "Tocar instrumento", type = "scenario", data = {anim = "WORLD_HUMAN_MUSICIAN"}},
        {label = "Dj", type = "anim", data = {lib = "anim@amb@nightclub@dancers@podium_dancers@", anim = "hi_dance_facedj_17_v2_male^5"}},
        {label = "Agarrar cerveza", type = "scenario", data = {anim = "WORLD_HUMAN_DRINKING"}},
        {label = "Beber cerveza", type = "scenario", data = {anim = "WORLD_HUMAN_PARTYING"}},
        {label = "Guitarra aerea", type = "anim", data = {lib = "anim@mp_player_intcelebrationmale@air_guitar", anim = "air_guitar"}},
        {label = "F---ar en el aire", type = "anim", data = {lib = "anim@mp_player_intcelebrationfemale@air_shagging", anim = "air_shagging"}},
        {label = "Rock'n'roll", type = "anim", data = {lib = "mp_player_int_upperrock", anim = "mp_player_int_rock"}},
        {label = "Borracho", type = "anim", data = {lib = "amb@world_human_bum_standing@drunk@idle_a", anim = "idle_a"}},
        {label = "Vomitar coche", type = "anim", data = {lib = "oddjobs@taxi@tie", anim = "vomit_outside"}},
		{label = "Tumbado", type = "scenario", data = {anim = "WORLD_HUMAN_BUM_SLUMPED"}},----------
		{label = "Muy contento", type = "scenario", data = {anim = "WORLD_HUMAN_CHEERING"}},
		{label = "Limpiar jardin", type = "scenario", data = {anim = "WORLD_HUMAN_GARDENER_LEAF_BLOWER"}},
		{label = "Apoyado en la escoba", type = "scenario", data = {anim = "WORLD_HUMAN_JANITOR"}},
		{label = "Pagar parkimetro", type = "scenario", data = {anim = "PROP_HUMAN_PARKING_METER"}}, --- ganzua
		{label = "Esperando", type = "scenario", data = {anim = "CODE_HUMAN_CROSS_ROAD_WAIT"}},

        } 
    },
 
    {
        name  = 'work',
        label = 'Trabajos',
        items = {
        {label = "Taxi : Hablando con cliente", type = "anim", data = {lib = "oddjobs@taxi@driver", anim = "leanover_idle"}},
        {label = "Pescar", type = "scenario", data = {anim = "world_human_stand_fishing"}},
        {label = "Policia : Investigando el suelo", type = "anim", data = {lib = "amb@code_human_police_investigate@idle_b", anim = "idle_f"}},
        {label = "Policia : Control del trafico", type = "scenario", data = {anim = "WORLD_HUMAN_CAR_PARK_ATTENDANT"}},
        {label = "Excavar suelo", type = "scenario", data = {anim = "world_human_gardener_plant"}},
        {label = "Mecanico : Reparar motor", type = "anim", data = {lib = "mini@repair", anim = "fixing_a_ped"}},
        {label = "EMS : Obsevando", type = "scenario", data = {anim = "CODE_HUMAN_MEDIC_KNEEL"}},
        {label = "Cargar en mesa", type = "anim", data = {lib = "mp_am_hold_up", anim = "purchase_beerbox_shopkeeper"}},
        {label = "Martillear pared", type = "scenario", data = {anim = "WORLD_HUMAN_HAMMERING"}},
        {label = "Cartel", type = "scenario", data = {anim = "WORLD_HUMAN_BUM_FREEWAY"}},
        {label = "Estatua humana", type = "scenario", data = {anim = "WORLD_HUMAN_HUMAN_STATUE"}},
        }
    },
 
    {
        name  = 'humors',
        label = 'tipos de humor',
        items = {
        {label = "Aplaudir", type = "scenario", data = {anim = "WORLD_HUMAN_CHEERING"}},
        {label = "Pulgares arriba", type = "anim", data = {lib = "mp_action", anim = "thanks_male_06"}},
        {label = "Puntos", type = "anim", data = {lib = "gestures@m@standing@casual", anim = "gesture_point"}},
        {label = "Vamonos", type = "anim", data = {lib = "gestures@m@standing@casual", anim = "gesture_come_here_soft"}},
        {label = "Incredulo", type = "anim", data = {lib = "gestures@m@standing@casual", anim = "gesture_bring_it_on"}},
        {label = "Yo", type = "anim", data = {lib = "gestures@m@standing@casual", anim = "gesture_me"}},
        {label = "Robar", type = "anim", data = {lib = "anim@am_hold_up@male", anim = "shoplift_high"}},
        {label = "Vergüenza ajena", type = "anim", data = {lib = "anim@mp_player_intcelebrationmale@face_palm", anim = "face_palm"}},
        {label = "Calma", type = "anim", data = {lib = "gestures@m@standing@casual", anim = "gesture_easy_now"}},
        {label = "Asustado 1", type = "anim", data = {lib = "oddjobs@assassinate@multi@", anim = "react_big_variations_a"}},
        {label = "Asustado 2", type = "anim", data = {lib = "amb@code_human_cower_stand@male@react_cowering", anim = "base_right"}},
        {label = "Mierda", type = "anim", data = {lib = "gestures@m@standing@casual", anim = "gesture_damn"}},
        {label = "Abrazo y beso", type = "anim", data = {lib = "mp_ped_interaction", anim = "kisses_guy_a"}},
        {label = "Jodete!", type = "anim", data = {lib = "mp_player_int_upperfinger", anim = "mp_player_int_finger_01_enter"}},
        {label = "Suicidio", type = "anim", data = {lib = "mp_suicide", anim = "pistol"}},
        }
    },
 
    {
        name  = 'sports',
        label = 'Deportes',
        items = {
        {label = "Presumir", type = "anim", data = {lib = "amb@world_human_muscle_flex@arms_at_side@base", anim = "base"}},
        {label = "Levantar peso", type = "anim", data = {lib = "amb@world_human_muscle_free_weights@male@barbell@base", anim = "base"}},
        {label = "Flexiones", type = "anim", data = {lib = "amb@world_human_push_ups@male@base", anim = "base"}},
        {label = "Abdominales", type = "anim", data = {lib = "amb@world_human_sit_ups@male@base", anim = "base"}},
        {label = "Yoga", type = "anim", data = {lib = "amb@world_human_yoga@male@base", anim = "base_a"}},
		{label = "Corriendo en el sitio", type = "scenario", data = {anim = "WORLD_HUMAN_JOG_STANDING"}},
        {label = "Calentar", type = "anim", data = {lib = "anim@deathmatch_intros@unarmed", anim = "intro_male_unarmed_e"}},
        }
    },
 
    {
        name  = 'misc',
        label = 'Misc',
        items = {
        {label = "Beber cafe", type = "anim", data = {lib = "amb@world_human_aa_coffee@idle_a", anim = "idle_a"}},
        {label = "Tumbarse boca arriba", type = "scenario", data = {anim = "WORLD_HUMAN_SUNBATHE_BACK"}},
        {label = "tumbarse boca abajo", type = "scenario", data = {anim = "WORLD_HUMAN_SUNBATHE"}},
        {label = "Limpiar ventana", type = "scenario", data = {anim = "WORLD_HUMAN_MAID_CLEAN"}},
        {label = "Cocinar barbacoa", type = "scenario", data = {anim = "PROP_HUMAN_BBQ"}},
        {label = "Forma de T", type = "anim", data = {lib = "mini@prostitutes@sexlow_veh", anim = "low_car_bj_to_prop_female"}},
        {label = "Hacer shelfie", type = "scenario", data = {anim = "world_human_tourist_mobile"}},
        {label = "Escuchar en la puerta",type = "anim", data = {lib = "mini@safe_cracking", anim = "idle_base"}},
        }
    },
	
	{
		name  = 'attitudem',
		label = 'Formas de caminar',
		items = {
	    {label = "Normal Hombre", type = "attitude", data = {lib = "move_m@confident", anim = "move_m@confident"}},
	    {label = "Normal Mujer", type = "attitude", data = {lib = "move_f@heels@c", anim = "move_f@heels@c"}},
	    {label = "Depresivo", type = "attitude", data = {lib = "move_m@depressed@a", anim = "move_m@depressed@a"}},
	    {label = "Depresiva", type = "attitude", data = {lib = "move_f@depressed@a", anim = "move_f@depressed@a"}},
	    {label = "De Negocios", type = "attitude", data = {lib = "move_m@business@a", anim = "move_m@business@a"}},
	    {label = "Determinado", type = "attitude", data = {lib = "move_m@brave@a", anim = "move_m@brave@a"}},
	    {label = "Casual", type = "attitude", data = {lib = "move_m@casual@a", anim = "move_m@casual@a"}},
	    {label = "Musculoso", type = "attitude", data = {lib = "move_m@fat@a", anim = "move_m@fat@a"}},
	    {label = "Hipster", type = "attitude", data = {lib = "move_m@hipster@a", anim = "move_m@hipster@a"}},
	    {label = "Lesionado", type = "attitude", data = {lib = "move_m@injured", anim = "move_m@injured"}},
	    {label = "Intimidado", type = "attitude", data = {lib = "move_m@hurry@a", anim = "move_m@hurry@a"}},
	    {label = "Desorientado", type = "attitude", data = {lib = "move_m@hobo@a", anim = "move_m@hobo@a"}},
	    {label = "Cabizbajo", type = "attitude", data = {lib = "move_m@sad@a", anim = "move_m@sad@a"}},
	    {label = "Ligero", type = "attitude", data = {lib = "move_m@shocked@a", anim = "move_m@shocked@a"}},
	    {label = "Cabeza alta", type = "attitude", data = {lib = "move_m@shadyped@a", anim = "move_m@shadyped@a"}},
	    {label = "Presionado", type = "attitude", data = {lib = "move_m@hurry_butch@a", anim = "move_m@hurry_butch@a"}},
	    {label = "Orgulloso", type = "attitude", data = {lib = "move_m@money", anim = "move_m@money"}},
	    {label = "A pasitos", type = "attitude", data = {lib = "move_m@quick", anim = "move_m@quick"}},
	    {label = "Moviendo caderas", type = "attitude", data = {lib = "move_f@maneater", anim = "move_f@maneater"}},
	    {label = "Mujer con prisa", type = "attitude", data = {lib = "move_f@sassy", anim = "move_f@sassy"}},	
	    {label = "Arrogante", type = "attitude", data = {lib = "move_f@arrogant@a", anim = "move_f@arrogant@a"}},
		}
	},

    {
        name  = 'porn',
        label = 'Calientes',
        items = {
		
        {label = "Mamada en el coche", type = "anim", data = {lib = "oddjobs@towing", anim = "m_blow_job_loop"}},
        {label = "Dando cabeza en coche", type = "anim", data = {lib = "oddjobs@towing", anim = "f_blow_job_loop"}},
        {label = "Chico sexo en el coche 1", type = "anim", data = {lib = "mini@prostitutes@sexlow_veh", anim = "low_car_sex_loop_player"}},
        {label = "Chico sexo en el coche 2", type = "anim", data = {lib = "oddjobs@assassinate@vice@sex", anim = "frontseat_carsex_loop_m"}},	
        {label = "Tocarse paquete", type = "anim", data = {lib = "mp_player_int_uppergrab_crotch", anim = "mp_player_int_grab_crotch"}},
        {label = "Puta", type = "anim", data = {lib = "mini@strip_club@idles@stripper", anim = "stripper_idle_02"}},
        {label = "Puta fumando", type = "scenario", data = {anim = "WORLD_HUMAN_PROSTITUTE_HIGH_CLASS"}},
        {label = "Puta caliente", type = "anim", data = {lib = "mini@strip_club@backroom@", anim = "stripper_b_backroom_idle_b"}},
        {label = "Striptease 1", type = "anim", data = {lib = "mini@strip_club@lap_dance@ld_girl_a_song_a_p1", anim = "ld_girl_a_song_a_p1_f"}},
        {label = "Striptease 2", type = "anim", data = {lib = "mini@strip_club@private_dance@part2", anim = "priv_dance_p2"}},
        {label = "Striptease 3", type = "anim", data = {lib = "mini@strip_club@private_dance@part3", anim = "priv_dance_p3"}},	
        {label = "Masturbarse", type = "anim", data = {lib = "mp_player_int_upperwank", anim = "mp_player_int_wank_01"}},
        }
    },
 
}