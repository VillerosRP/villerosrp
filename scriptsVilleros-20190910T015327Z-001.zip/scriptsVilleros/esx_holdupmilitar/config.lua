Config = {}
Config.Locale = 'en'
Config.NumberOfCopsRequired = 7

Banks = {
	["barco"] = {
		position = { ['x'] = 3035.65, ['y'] = -4684.97, ['z'] = 5.50 },
		reward = math.random(500000,600000),
		nameofbank = "(PortaAviones) A.R.A 25DEMAYO",
		lastrobbed = 0
	}
}