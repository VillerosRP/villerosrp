Locales['en'] = {

	['robbery_cancelled'] = 'el robo será cancelado, ¡no ganarás nada!!',
	['robbery_successful'] = 'robo exitoso que ha ganado  ~g~$',
	['bank_robbery'] = 'Robo a Laboratorios BAGO',
	['press_to_rob'] = 'presiona ~INPUT_CONTEXT~ para robar ~b~',
	['robbery_of'] = 'Robo a Laboratorios BAGO: ~r~',
	['seconds_remaining'] = '~w~ segundos para terminar',
	['robbery_cancelled_at'] = '~r~ Robo cancelado: ~b~',
	['robbery_has_cancelled'] = '~r~ el robo a sido cancelado: ~b~',
	['already_robbed'] = 'Este robo ya ha hecho. Espere: ',
	['seconds'] = 'segundos.',
	['rob_in_prog'] = '~r~ robo en progreso: ~b~',
	['started_to_rob'] = 'has comenzado el robo ',
	['do_not_move'] = ', no te muevas!',
	['alarm_triggered'] = 'la alarma esta sonando',
	['hold_pos'] = 'espera 5 minutos y el dinero es tuyo!',
	['robbery_complete'] = '~r~ robo completado.~s~ ~h~ corre!',
	['robbery_complete_at'] = '~r~ Robo completado en: ~b~',
	['min_two_police'] = 'debe haber al menos ~b~8 policias~s~ en la ciudad para atracar.',
	['robbery_already'] = '~r~el robo esta en progreso.',

}