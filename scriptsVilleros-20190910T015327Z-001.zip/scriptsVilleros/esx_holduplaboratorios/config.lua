Config = {}
Config.Locale = 'en'
Config.NumberOfCopsRequired = 5

Banks = {
	["laboratoriosbago"] = {
		position = { ['x'] = 3540.58, ['y'] = 3667.1, ['z'] = 28.50 },
		reward = math.random(200000,300000),
		nameofbank = "Robo laboritorios BAGO ",
		lastrobbed = 0
	}
}