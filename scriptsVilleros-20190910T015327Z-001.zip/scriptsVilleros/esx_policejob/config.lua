Config                            = {}

Config.DrawDistance               = 100.0
Config.MarkerType                 = 27
Config.MarkerSize                 = { x = 1.5, y = 1.5, z = 0.5 }
Config.MarkerColor                = { r = 50, g = 50, b = 204 }

Config.EnablePlayerManagement     = true
Config.EnableArmoryManagement     = true
Config.EnableESXIdentity          = true -- enable if you're using esx_identity
Config.EnableNonFreemodePeds      = false -- turn this on if you want custom peds
Config.EnableSocietyOwnedVehicles = false
Config.EnableLicenses             = true -- enable if you're using esx_license

Config.EnableHandcuffTimer        = true -- enable handcuff timer? will unrestrain player after the time ends
Config.HandcuffTimer              = 20 * 60000 -- 10 mins

Config.EnableJobBlip              = true -- enable blips for colleagues, requires esx_society

Config.MaxInService               = -1
Config.Locale = 'en'

Config.PoliceStations = {

  LSPD1 = {

    Blip = {
      Pos     = { x = 425.130, y = -979.558, z = 30.711 },
      Sprite  = 60,
      Display = 5,
      Scale   = 1.2,
      Colour  = 29,
    },

    AuthorizedWeapons = {
      { name = 'WEAPON_FLASHLIGHT',       price = 80 },	
	  { name = 'WEAPON_VINTAGEPISTOL',    price = 250 },	
      { name = 'WEAPON_NIGHTSTICK',       price = 200 },	
      { name = 'WEAPON_STUNGUN',          price = 500 },	
      { name = 'WEAPON_COMBATPISTOL',     price = 2000 },
	  { name = 'WEAPON_PISTOL',           price = 1000 },
      { name = 'WEAPON_PISTOL50',         price = 3000 }, 	  
	  { name = 'WEAPON_SMG',              price = 2500 },
	  { name = 'WEAPON_PUMPSHOTGUN',      price = 4000 },
	  { name = 'WEAPON_COMBATPDW',        price = 5000 },
      { name = 'WEAPON_CARBINERIFLE',     price = 7500 },
	  { name = 'GADGET_PARACHUTE',        price = 300 },

    },

    Cloakrooms = {
      {x = 452.600, y = -993.306, z = 29.750}
    },

    Armories = {
      {x = 452.04, y = -980.17, z = 30.00} -- 459.03 -979.78
    },

    Vehicles = {
      {
        Spawner    = {x = 454.69, y = -1017.4, z = 27.450},
        SpawnPoints = {
			{ x = 438.42, y = -1018.30, z = 27.75, heading = 90.0, radius = 6.0 },
			{ x = 441.08, y = -1024.23, z = 28.30, heading = 90.0, radius = 6.0 },
			{ x = 453.53, y = -1022.20, z = 28.02, heading = 90.0, radius = 6.0 },
			{ x = 450.97, y = -1016.55, z = 28.10, heading = 90.0, radius = 6.0 }
		}
    },
	
	  {
		Spawner    = { x = 415.89, y = -1017.39, z = 29.04 },
		SpawnPoints = {
			{ x = 475.98, y = -1021.65, z = 28.06, heading = 276.11, radius = 6.0 },
			{ x = 484.10, y = -1023.19, z = 27.57, heading = 302.54, radius = 6.0 }
		}
	}
},

    Helicopters = {
      {
        Spawner    = {x = 466.477, y = -982.819, z = 42.695},
        SpawnPoint = {x = 450.04, y = -981.14, z = 42.695},
		Heading    = 0.0
      }
    },

    VehicleDeleters = {
      {x = 446.98, y = -1008.39, z = 28.2},
      {x = 462.40, y = -1019.7, z = 27.115}
    },

    BossActions = {
      {x = 448.417, y = -973.208, z = 29.693}
    }

  },

  --[[SASP1 = {
    Blip = {
      Pos   = {x = 825.34204101563, y = -1290.0471191406, z = 28.240659713745 },
	  Sprite  = 60,
      Display = 4,
      Scale   = 1.2,
      Color = 40
    },

    AuthorizedWeapons = {
      { name = 'WEAPON_FLASHLIGHT',       price = 80 },	
      { name = 'WEAPON_NIGHTSTICK',       price = 200 },	
      { name = 'WEAPON_STUNGUN',          price = 500 },	
      { name = 'WEAPON_COMBATPISTOL',     price = 1000 },
      { name = 'WEAPON_PUMPSHOTGUN',      price = 2000 },  	  
	  { name = 'WEAPON_SMG',              price = 1250 },
      { name = 'WEAPON_ASSAULTSMG',       price = 2000 },
      { name = 'WEAPON_CARBINERIFLE',     price = 3000 },
	  { name = 'WEAPON_ADVANCEDRIFLE',    price = 4000 },
      { name = 'WEAPON_CARBINERIFLE_MK2', price = 5000 },
      { name = 'WEAPON_SPECIALCARBINE',   price = 6000 },
	  { name = 'WEAPON_SMOKEGRENADE',     price = 300 },
	  { name = 'WEAPON_BZGAS',            price = 300 },
	  { name = 'GADGET_PARACHUTE',        price = 300 },

    },

    Cloakrooms = {
      {x = -3257.4528808594, y = 1225.7932128906, z = 2.6499989032745}
    },

    Armories = {
      {x = -3257.2766113281, y = 1219.7313232422, z = 2.6399991512299}
    },

    Vehicles = {
      {
        Spawner    = {x = -3253.5500488281, y = 1213.4896240234, z = 2.5500111579895}, 
        SpawnPoints = {x = -3280.9311523438, y = 1209.7053222656, z = 1.0662420988083}

      }
    },

    Helicopters = {
      {
        Spawner    = {x = -3254.4692382813, y = 1232.7946777344, z = 2.5586361885071},
        SpawnPoint = {x = -3250.7421875, y = 1247.4985351563, z = 2.6209080219269},
        Heading    = 0.0
      }
    },

    VehicleDeleters = {
      {x = -3258.955078125, y = 1206.6640625, z = 2.6051046848297}
    },

    BossActions = {
      {x = -3253.4951171875, y = 1221.609375, z = 2.6699986457825}
    }

  },]]--

  LSPD2 = {
    Blip = {
      Pos   = {x = -441.80764770508, y = 6012.5131835938, z = 31.716369628906 },
      Sprite  = 60,
      Display = 4,
      Scale   = 1.0,
      Color = 40
    },

    AuthorizedWeapons = {
      { name = 'WEAPON_FLASHLIGHT',       price = 80 },	
	  { name = 'WEAPON_VINTAGEPISTOL',    price = 250 },	
      { name = 'WEAPON_NIGHTSTICK',       price = 200 },	
      { name = 'WEAPON_STUNGUN',          price = 500 },	
      { name = 'WEAPON_COMBATPISTOL',     price = 1000 },  	  
	  { name = 'WEAPON_SMG',              price = 2500 },
      { name = 'WEAPON_CARBINERIFLE',     price = 5000 },
	  { name = 'WEAPON_SMOKEGRENADE',     price = 300 },
	  { name = 'WEAPON_BZGAS',            price = 300 },
	  { name = 'GADGET_PARACHUTE',        price = 300 },

    },

    Cloakrooms = {
      {x = -449.63, y = 6016.29, z = 31.76-1.0001 },
    },

    Armories = {
      {x = -448.05, y = 6007.71, z = 31.75-1.0001 },
    },

    Vehicles = {
      {
        Spawner    = {x = -452.3, y = 6005.67, z = 31.88-1.0001 },
        SpawnPoints = {
		    {x = -454.96899414063, y = 6001.8876953125, z = 31.340549468994-1.0001, heading = 90.0, radius = 6.0 }
      }
	}
 },

    Helicopters = {
      {
        Spawner    = {x = -462.88317871094, y = 5993.7685546875, z = 31.245756149292-1.0001 },
        SpawnPoint = {x = -475.48043823242, y = 5988.326171875, z = 31.336708068848-1.0001 },
		Heading    = 0.0
      }
    },

    VehicleDeleters = {
      {x = 446.98, y = -1008.39, z = 28.2 },
    },

    BossActions = {
      {x = -449.5, y = 6010.17, z = 31.72-1.0001 },
    }

  },

  SASP2 = {
    Blip = {
      Pos   = {x = 1852.86, y = 3689.45, z = 34.27 },
      Sprite  = 60,
      Display = 4,
      Scale   = 1.0,
      Color = 40
    },

    AuthorizedWeapons = {
      { name = 'WEAPON_FLASHLIGHT',       price = 80 },	
	  { name = 'WEAPON_VINTAGEPISTOL',    price = 250 },	
      { name = 'WEAPON_NIGHTSTICK',       price = 200 },	
      { name = 'WEAPON_STUNGUN',          price = 500 },	
      { name = 'WEAPON_COMBATPISTOL',     price = 1000 },  	  
	  { name = 'WEAPON_SMG',              price = 2500 },
      { name = 'WEAPON_CARBINERIFLE',     price = 5000 },
	  { name = 'GADGET_PARACHUTE',        price = 300 },
	  
    },

    Cloakrooms = {
      {x = 1857.0, y = 3689.51, z = 34.27-1.0001 }, -- state pd
    },

    Armories = {
      {x = 1848.48, y = 3690.19, z = 34.28-1.0001 }, -- state pd
    },

    Vehicles = {
      {
        Spawner    = {x = 1866.22, y = 3693.81, z = 33.77-1.0001 }, --state pd
        SpawnPoints = {
		    {x = 1872.9417724609, y = 3690.5759277344, z = 33.569362640381-1.0001, heading = 90.0, radius = 6.0 }  -- state pd
      }
	}  
 },

    Helicopters = {
      {
        Spawner    = {x = 466.477, y = -982.819, z = 42.691-1.0001 },
        SpawnPoint = {x = 450.04, y = -981.14, z = 42.691-1.0001 },
		Heading    = 0.0
      }
    },

    VehicleDeleters = {
      {x = 446.98, y = -1008.39, z = 28.2-1.0001 }, --state pd
    },

    BossActions = {
      {x = 1851.28, y = 3690.74, z = 34.28-1.0001 }, --state pd
    }

  }

}


-- https://wiki.rage.mp/index.php?title=Vehicles
Config.AuthorizedVehicles = {

    Shared = {
		{
			model = 'sheriff',
			label = 'Auto AYUDANTE'
		},
		{
			model = 'pbus3',
			label = 'Autobus'
		},
		{
			model = 'hcbr500rgn',
			label = 'Moto Cbr'
		},
		{
			model = 'fbi',
			label = 'FBI'
		},
		{
			model = 'policefelon',
			label = 'Unidad de Incognito'
		},
		{
			model = 'fbi3',
			label = 'Kuruma'
		},
		{
			model = 'police',
			label = 'Dodge'
		},
		{
			model = 'police',
			label = 'Dodge'
		},
		{
			model = 'sapickup',
			label = 'Unidad de Transito'
		},
		{
			model = 'pranger',
			label = 'Chevrolet'
		},
		{
			model = 'polgs350',
			label = 'Lexus'
		},
		{
			model = 'anpc_l200',
			label = 'Mitsubishi'
		},
		{
			model = '2015polstang',
			label = 'Mustang'
		},
		{
			model = 'police5',
			label = 'Unidad Canina'
		}
	},
	
	recruta = {
		{
			model = 'sheriff',
			label = 'Auto AYUDANTE'
		}
	},

	guarda = {
		{
			model = 'police',
			label = 'Patrulla OFICIAL'
		}

	},

	soldado = {
	    {
			model = 'police3',
			label = 'FORD KUGA'
		},
		{
			model = 'police',
			label = 'Impala'
		}
	},
	
	cabo = {
	    		{
			model = 'police2',
			label = 'DODGE'
		},
		{
			model = 'police3',
			label = 'FORD KUGA'
		},
		{
			model = 'policeb',
			label = 'Honda tornado'
		}
	},

	sargento3 = {
	    {
			model = 'police2',
			label = 'DODGE'
		},
		{
			model = 'policeb',
			label = 'Honda tornado'
		},
		{
			model = 'police3',
			label = 'KUGA'
		},
		{
			model = 'policer8',
			label = 'Audi r8'
		}
	},
	
	sargento2 = {
	    {
			model = 'policeb',
			label = 'Moto'
		},
		{
			model = 'police3',
			label = 'KUGA'
		},
		{
			model = 'police2',
			label = 'DODGE'
		},
		{
			model = 'policer8',
			label = 'AudiR8'
		},
		{
			model = 'bearcatBCSO',
			label = 'CAMIONETA GEOF'
		}
	},
	
	sargento1 = {
	    {
			model = 'policeb',
			label = 'Moto'
		},
		{
			model = 'police3',
			label = 'KUGA'
		},
		{
			model = 'police2',
			label = 'DODGE'
		},
		{
			model = 'policer8',
			label = 'AudiR8'
		},
		{
			model = 'bearcatBCSO',
			label = 'CAMIONETA GEOF'
		}
	},

	tenente3 = {
	    {
			model = 'policeb',
			label = 'Moto'
		},
		{
			model = 'police3',
			label = 'KUGA'
		},
		{
			model = 'police2',
			label = 'DODGE'
		},
		{
			model = 'policer8',
			label = 'AudiR8'
		},
		{
			model = 'bearcatBCSO',
			label = 'CAMIONETA GEOF'
		}
	},
	
	tenente2 = {
	    {
			model = 'policeb',
			label = 'Moto'
		},
		{
			model = 'police3',
			label = 'KUGA'
		},
		{
			model = 'police2',
			label = 'DODGE'
		},
		{
			model = 'policer8',
			label = 'AudiR8'
		},
		{
			model = 'bearcatBCSO',
			label = 'CAMIONETA GEOF'
		}
	},
	
	tenente1 = {
	    {
			model = 'policeb',
			label = 'Moto'
		},
		{
			model = 'police3',
			label = 'KUGA'
		},
		{
			model = 'police2',
			label = 'DODGE'
		},
		{
			model = 'policer8',
			label = 'AudiR8'
		},
		{
			model = 'bearcatBCSO',
			label = 'CAMIONETA GEOF'
		}
	},

	capitao = {
	    {
			model = 'policeb',
			label = 'Moto'
		},
		{
			model = 'police3',
			label = 'KUGA'
		},
		{
			model = 'police2',
			label = 'DODGE'
		},
		{
			model = 'policer8',
			label = 'AudiR8'
		},
		{
			model = 'bearcatBCSO',
			label = 'CAMIONETA GEOF'
		}
	},

	major = {
	    {
			model = 'policeb',
			label = 'Moto'
		},
		{
			model = 'police3',
			label = 'KUGA'
		},
		{
			model = 'police2',
			label = 'DODGE'
		},
		{
			model = 'policer8',
			label = 'AudiR8'
		},
		{
			model = 'bearcatBCSO',
			label = 'CAMIONETA GEOF'
		}
	},
	
	cv_recruta_civil = {
		{
			model = 'policeb',
			label = 'Moto'
		},
		{
			model = 'police3',
			label = 'KUGA'
		},
		{
			model = 'police2',
			label = 'DODGE'
		},
		{
			model = 'policer8',
			label = 'AudiR8'
		},
		{
			model = 'bearcatBCSO',
			label = 'CAMIONETA GEOF'
		}
	},
	
	cv_investigador = {
		{
			model = 'policeb',
			label = 'Moto'
		},
		{
			model = 'police3',
			label = 'KUGA'
		},
		{
			model = 'police2',
			label = 'DODGE'
		},
		{
			model = 'policer8',
			label = 'AudiR8'
		},
		{
			model = 'bearcatBCSO',
			label = 'CAMIONETA GEOF'
		}
	},
	
	cv_delegado = {
	    {
			model = 'policeb',
			label = 'Moto'
		},
		{
			model = 'police3',
			label = 'KUGA'
		},
		{
			model = 'police2',
			label = 'DODGE'
		},
		{
			model = 'policer8',
			label = 'AudiR8'
		},
		{
			model = 'bearcatBCSO',
			label = 'CAMIONETA GEOF'
		}
	},

	boss = {
		{
			model = 'police2',
			label = 'DODGE'
		},
		{
			model = 'police',
			label = 'Auto recluta'
		},
		{
			model = 'police3',
			label = 'KUGA'
		},
		{
			model = 'policer8',
			label = 'AudiR8'
		},
		{
			model = 'bearcatBCSO',
			label = 'GEOF'
		},
		{
			model = 'brickade2',
			label = 'BLINDADO'
		},
		{
			model = 'riot',
			label = 'Antidisturbios'
		},
		
		{
			model = 'riot2',
			label = 'Hidrante'
		}
	}
}


-- CHECK SKINCHANGER CLIENT MAIN.LUA for matching elements

Config.Uniforms = {
	cv_recruta_civil_wear = {
		male = {
			['tshirt_1'] = 122,  ['tshirt_2'] = 0,
			['torso_1'] = 188,   ['torso_2'] = 7,
			['decals_1'] = 0,   ['decals_2'] = 2,
			['arms'] = 30,
			['pants_1'] = 31,   ['pants_2'] = 0,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['helmet_1'] = -1,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 2,     ['ears_2'] = 0
		},
		female = {
			['tshirt_1'] = 35,  ['tshirt_2'] = 0,
			['torso_1'] = 48,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 44,
			['pants_1'] = 34,   ['pants_2'] = 0,
			['shoes_1'] = 27,   ['shoes_2'] = 0,
			['helmet_1'] = 45,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 2,     ['ears_2'] = 0
		}
	},
	cv_investigador_wear = {
		male = {
			['tshirt_1'] = 122,  ['tshirt_2'] = 0,
			['torso_1'] = 188,   ['torso_2'] = 7,
			['decals_1'] = 0,   ['decals_2'] = 2,
			['arms'] = 30,
			['pants_1'] = 31,   ['pants_2'] = 0,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['helmet_1'] = -1,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 2,     ['ears_2'] = 0
		},
		female = {
			['tshirt_1'] = 35,  ['tshirt_2'] = 0,
			['torso_1'] = 48,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 30,
			['pants_1'] = 34,   ['pants_2'] = 0,
			['shoes_1'] = 27,   ['shoes_2'] = 0,
			['helmet_1'] = 45,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 2,     ['ears_2'] = 0
		}
	},
	cv_delegado_wear = {
		male = {
			['tshirt_1'] = 122,  ['tshirt_2'] = 0,
			['torso_1'] = 188,   ['torso_2'] = 7,
			['decals_1'] = 0,   ['decals_2'] = 2,
			['arms'] = 30,
			['pants_1'] = 31,   ['pants_2'] = 0,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['helmet_1'] = -1,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 2,     ['ears_2'] = 0
		},
		female = {
			['tshirt_1'] = 35,  ['tshirt_2'] = 0,
			['torso_1'] = 48,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 30,
			['pants_1'] = 34,   ['pants_2'] = 0,
			['shoes_1'] = 27,   ['shoes_2'] = 0,
			['helmet_1'] = 45,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 2,     ['ears_2'] = 0
		}
	},
	recruta_wear = {
		male = {
			['tshirt_1'] = 122,  ['tshirt_2'] = 0,
			['torso_1'] = 188,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 30,
			['pants_1'] = 31,   ['pants_2'] = 0,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['helmet_1'] = -1,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 2,     ['ears_2'] = 0
		},
		female = {
			['tshirt_1'] = 35,  ['tshirt_2'] = 0,
			['torso_1'] = 48,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 30,
			['pants_1'] = 34,   ['pants_2'] = 0,
			['shoes_1'] = 27,   ['shoes_2'] = 0,
			['helmet_1'] = 45,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 2,     ['ears_2'] = 0
		}
	},
	guarda_wear = {
		male = {
			['tshirt_1'] = 122,  ['tshirt_2'] = 0,
			['torso_1'] = 188,   ['torso_2'] = 1,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 30,
			['pants_1'] = 31,   ['pants_2'] = 0,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['helmet_1'] = -1,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 2,     ['ears_2'] = 0
		},
		female = {
			['tshirt_1'] = 122,  ['tshirt_2'] = 0,
			['torso_1'] = 188,   ['torso_2'] = 2,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 30,
			['pants_1'] = 34,   ['pants_2'] = 0,
			['shoes_1'] = 27,   ['shoes_2'] = 0,
			['helmet_1'] = 45,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 2,     ['ears_2'] = 0
		}
	},
	soldado_wear = {
		male = {
			['tshirt_1'] = 122,  ['tshirt_2'] = 0,
			['torso_1'] = 188,   ['torso_2'] = 2,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 30,
			['pants_1'] = 31,   ['pants_2'] = 0,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['helmet_1'] = -1,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 2,     ['ears_2'] = 0
		},
		female = {
			['tshirt_1'] = 35,  ['tshirt_2'] = 0,
			['torso_1'] = 48,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 30,
			['pants_1'] = 34,   ['pants_2'] = 0,
			['shoes_1'] = 27,   ['shoes_2'] = 0,
			['helmet_1'] = -1,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 2,     ['ears_2'] = 0
		}
	},
	cabo_wear = {
		male = {
			['tshirt_1'] = 122,  ['tshirt_2'] = 0,
			['torso_1'] = 188,   ['torso_2'] = 3,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 30,
			['pants_1'] = 31,   ['pants_2'] = 0,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['helmet_1'] = -1,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 2,     ['ears_2'] = 0
		},
		female = {
			['tshirt_1'] = 35,  ['tshirt_2'] = 0,
			['torso_1'] = 48,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 30,
			['pants_1'] = 34,   ['pants_2'] = 0,
			['shoes_1'] = 27,   ['shoes_2'] = 0,
			['helmet_1'] = -1,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 2,     ['ears_2'] = 0
		}
	},
	sargento_wear = {
		male = {
			['tshirt_1'] = 122,  ['tshirt_2'] = 0,
			['torso_1'] = 188,   ['torso_2'] = 4,
			['decals_1'] = 8,   ['decals_2'] = 1,
			['arms'] = 30,
			['pants_1'] = 31,   ['pants_2'] = 0,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['helmet_1'] = -1,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 2,     ['ears_2'] = 0
		},
		female = {
			['tshirt_1'] = 35,  ['tshirt_2'] = 0,
			['torso_1'] = 48,   ['torso_2'] = 0,
			['decals_1'] = 7,   ['decals_2'] = 1,
			['arms'] = 30,
			['pants_1'] = 34,   ['pants_2'] = 0,
			['shoes_1'] = 27,   ['shoes_2'] = 0,
			['helmet_1'] = -1,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 2,     ['ears_2'] = 0
		}
	},
	tenente_wear = {
		male = {
			['tshirt_1'] = 122,  ['tshirt_2'] = 0,
			['torso_1'] = 188,   ['torso_2'] = 6,
			['decals_1'] = 0,   ['decals_2'] = 2,
			['arms'] = 30,
			['pants_1'] = 31,   ['pants_2'] = 0,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['helmet_1'] = -1,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 2,     ['ears_2'] = 0
		},
		female = {
			['tshirt_1'] = 35,  ['tshirt_2'] = 0,
			['torso_1'] = 48,   ['torso_2'] = 0,
			['decals_1'] = 7,   ['decals_2'] = 2,
			['arms'] = 30,
			['pants_1'] = 34,   ['pants_2'] = 0,
			['shoes_1'] = 27,   ['shoes_2'] = 0,
			['helmet_1'] = -1,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 2,     ['ears_2'] = 0
		}
	},
	catitao_wear = { -- currently the same as intendent_wear
		male = {
			['tshirt_1'] = 122,  ['tshirt_2'] = 0,
			['torso_1'] = 188,   ['torso_2'] = 7,
			['decals_1'] = 0,   ['decals_2'] = 2,
			['arms'] = 30,
			['pants_1'] = 31,   ['pants_2'] = 0,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['helmet_1'] = -1,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 2,     ['ears_2'] = 0
		},
		female = {
			['tshirt_1'] = 35,  ['tshirt_2'] = 0,
			['torso_1'] = 48,   ['torso_2'] = 0,
			['decals_1'] = 7,   ['decals_2'] = 2,
			['arms'] = 30,
			['pants_1'] = 34,   ['pants_2'] = 0,
			['shoes_1'] = 27,   ['shoes_2'] = 0,
			['helmet_1'] = -1,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 2,     ['ears_2'] = 0
		}
	},
	major_wear = {
		male = {
			['tshirt_1'] = 122,  ['tshirt_2'] = 0,
			['torso_1'] = 188,   ['torso_2'] = 5,
			['decals_1'] = 8,   ['decals_2'] = 3,
			['arms'] = 30,
			['pants_1'] = 31,   ['pants_2'] = 0,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['helmet_1'] = -1,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 2,     ['ears_2'] = 0
		},
		female = {
			['tshirt_1'] = 35,  ['tshirt_2'] = 0,
			['torso_1'] = 48,   ['torso_2'] = 0,
			['decals_1'] = 7,   ['decals_2'] = 3,
			['arms'] = 44,
			['pants_1'] = 34,   ['pants_2'] = 0,
			['shoes_1'] = 27,   ['shoes_2'] = 0,
			['helmet_1'] = -1,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 2,     ['ears_2'] = 0
		}
	},
	boss_wear = { -- currently the same as chef_wear
		male = {
			['tshirt_1'] = 122,  ['tshirt_2'] = 0,
			['torso_1'] = 188,   ['torso_2'] = 7,
			['decals_1'] = 0,   ['decals_2'] = 2,
			['arms'] = 30,
			['pants_1'] = 31,   ['pants_2'] = 0,
			['shoes_1'] = 25,   ['shoes_2'] = 0,
			['helmet_1'] = -1,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 2,     ['ears_2'] = 0
		},
		female = {
			['tshirt_1'] = 35,  ['tshirt_2'] = 0,
			['torso_1'] = 48,   ['torso_2'] = 0,
			['decals_1'] = 0,   ['decals_2'] = 0,
			['arms'] = 44,
			['pants_1'] = 31,   ['pants_2'] = 0,
			['shoes_1'] = 27,   ['shoes_2'] = 0,
			['helmet_1'] = 45,  ['helmet_2'] = 0,
			['chain_1'] = 0,    ['chain_2'] = 0,
			['ears_1'] = 2,     ['ears_2'] = 0
		}
	},
	bullet_wear = {
		male = {
			['bproof_1'] = 12,  ['bproof_2'] = 1
		},
		female = {
			['bproof_1'] = 13,  ['bproof_2'] = 1
		}
	},
	gilet_wear = {
		male = {
			['tshirt_1'] = 59,  ['tshirt_2'] = 1
		},
		female = {
			['tshirt_1'] = 36,  ['tshirt_2'] = 1
		}
	}
}