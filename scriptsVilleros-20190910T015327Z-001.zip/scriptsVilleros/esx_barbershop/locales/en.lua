Locales['en'] = {
  ['valid_purchase'] = 'Validar esta compra?',
  ['yes'] = 'Si',
  ['no'] = 'No',
  ['not_enough_money'] = 'Usted no tiene suficiente dinero',
  ['press_access'] = 'Presione ~INPUT_CONTEXT~ para acceder a la tienda',
  ['barber_blip'] = 'Barberia',
  ['you_paid'] = 'Usted pago $%s',
}
