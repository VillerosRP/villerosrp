Config                            = {}
Config.DrawDistance               = 100.0
Config.MarkerType                 = 1
Config.MarkerSize                 = { x = 1.5, y = 1.5, z = 1.0 }
Config.MarkerColor                = { r = 50, g = 50, b = 204 }
Config.EnablePlayerManagement     = true
Config.EnableArmoryManagement     = true
Config.EnableESXIdentity          = true -- only turn this on if you are using esx_identity
Config.EnableNonFreemodePeds      = false -- turn this on if you want custom peds
Config.EnableSocietyOwnedVehicles = false
Config.EnableLicenses             = false
Config.MaxInService               = -1
Config.Locale                     = 'en'

Config.drintStations = {

  drint = {

    Blip = {
      Pos     = { x = 425.130, y = -979.558, z = 30.711 },
      Sprite  = 60,
      Display = 4,
      Scale   = 1.2,
      Colour  = 29,
    },

    AuthorizedWeapons = {
      { name = 'WEAPON_COMBATPISTOL',     price = 17000 },
      { name = 'WEAPON_PUMPSHOTGUN',      price = 24000 },
      { name = 'WEAPON_FLARE',            price = 3000 },
      { name = 'WEAPON_SWITCHBLADE',      price = 8000 },
	  
    },

	  AuthorizedVehicles = {
		  { name = 'boxville2',  label = 'Camion recluta' },
	  },

    Cloakrooms = {
      { x = 985.13, y = -91.78, z = 74.85 },
    },

    Armories = {
      { x = 971.9, y = -98.9, z = 74.617 },
    },

    Vehicles = {
      {
        Spawner    = { x = 951.51, y = -123.21, z = 74.25 },
        SpawnPoint = { x = 961.76, y = -134.2, z = 75.266 },
        Heading    = 90.0,
      }
    },
	
	Helicopters = {
      {
        Spawner    = { x = 20.312, y = 535.667, z = 173.627 },
        SpawnPoint = { x = 956.87, y = -129.27, z = 74.38 },
        Heading    = 0.0,
      }
    },

    VehicleDeleters = {
      { x = 974.29, y = -130.9, z = 74.15 },
    },

    BossActions = {
      { x = 976.82, y = -103.62, z = 74.66 }
    },

  },

}
