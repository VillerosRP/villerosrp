Locales['br'] = {
  ['left_instance'] = 'você deixou a instância',
  ['invite_expired'] = 'convite expirado',
  ['press_to_enter'] = 'pressione ~INPUT_CONTEXT~ para entrar na instância',
  ['entered_instance'] = 'você entrou na instância',
  ['entered_into'] = '%s entered the instance',
  ['left_out'] = '%s left the instance',
}
