function SetData()
	local name = GetPlayerName(PlayerId())
	local id = GetPlayerServerId(PlayerId())
	Citizen.InvokeNative(GetHashKey("ADD_TEXT_ENTRY"), 'FE_THDR_GTAO', '~r~VillerosRP discord.gg/9DWPTP2 -> ~p~ID: ~p~' .. id .. ' -> ~g~Nombre: ~g~' .. name)
end

Citizen.CreateThread(function()
	while true do
		Citizen.Wait(100)
		SetData()
	end
end)