Locales ['en'] = {
  ['voice']   = '~y~Voz [Shift+U]: ~s~%s',
  ['normal']  = 'Normal',
  ['shout']   = 'Susurrar',
  ['whisper'] = 'Gritar',
}
