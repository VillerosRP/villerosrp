Locales['en'] = {
  ['activated']   = 'activated',
  ['deactivated'] = 'deactivated',
}
