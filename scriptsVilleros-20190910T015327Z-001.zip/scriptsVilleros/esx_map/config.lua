Config = {}

Config.Map = {
  {name="Hospital NegroPapoIV",color=2, id=153, x = 310.55, y = -591.19, z = 43.29},
  {name="Oficina Del Gobernador",color=1, id=515, x = -68.9, y = -792.23, z = 44.23},
  {name="Municipalidad de VillerosRP",color=5, id=480, x = -1090.39, y = -272.18, z = 37}


}