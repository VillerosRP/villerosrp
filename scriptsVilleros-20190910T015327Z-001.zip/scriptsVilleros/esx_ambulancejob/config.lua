Config                            = {}

Config.DrawDistance               = 100.0
Config.MarkerColor                = { r = 102, g = 0, b = 102 }
Config.MarkerSize                 = { x = 2.5, y = 2.5, z = 0.8 }
Config.ReviveReward               = 500  -- revive reward, set to 0 if you don't want it enabled
Config.AntiCombatLog              = true -- enable anti-combat logging?
Config.LoadIpl                    = false -- disable if you're using fivem-ipl or other IPL loaders
Config.Locale = 'en'

local second = 1000
local minute = 60 * second

Config.EarlyRespawnTimer          = 5 * minute  -- Time til respawn is available
Config.BleedoutTimer              = 5 * minute -- Time til the player bleeds out

Config.EnablePlayerManagement     = true
Config.EnableSocietyOwnedVehicles = false

Config.RemoveWeaponsAfterRPDeath  = true
Config.RemoveCashAfterRPDeath     = true
Config.RemoveItemsAfterRPDeath    = true

-- Let the player pay for respawning early, if he can afford it.
Config.EarlyRespawnFine           = false
Config.EarlyRespawnFineAmount     = 5000

Config.Blip = {
	Pos     = { x = 307.76, y = -1433.47, z = 28.97 },
	Sprite  = 367,
	Display = 4,
	Scale   = 1.0,
	Colour  = 1
}

Config.HelicopterSpawner = {
	SpawnPoint = { x = 313.33, y = -1465.2, z = 45.5 },
	Heading    = 0.0
}

-- https://wiki.rage.mp/index.php?title=Vehicles
Config.AuthorizedVehicles = {

  { model = 'ambulance',    label = 'Ambulancia' },
  { model = 'pbus',    label = 'Autobus Vacunas' },
  { model = 'fbi2',    label = 'Bmw x5' },
   { model = 'firerig',    label = 'Mercedes' },
   { model = 'as350',    label = 'Helicoptero' },
    { model = 'ghispo2',    label = 'Maserati' }

}

Config.Zones = {

	HospitalInteriorEntering1 = { -- Main entrance
		Pos	= { x = 293.21, y = -584.58, z = 13.18 },
		Type = 1
	},

	HospitalInteriorInside1 = {  -- APARECEMOS CUANDO MORIMOS ACA PAPA
		Pos	= { x = 293.21, y = -584.58, z = 43.18 },
		Type = -1
	},

	HospitalInteriorOutside1 = {
		Pos	= { x = 293.21, y = -584.58, z = 10.19 },
		Type = -1
	},

	HospitalInteriorExit1 = {
		Pos	= { x = 293.21, y = -584.58, z = 10.19 },
		Type = 1
	},

	HospitalInteriorEntering2 = { -- Lift go to the roof
		Pos	= { x = 247.1, y = -1371.4, z = 10.5 },
		Type = 1
	},

	HospitalInteriorInside2 = { -- Roof outlet
		Pos	= { x = 333.1,	y = -1434.9, z = 10.5 },
		Type = -1
	},

	HospitalInteriorOutside2 = { -- Lift back from roof
		Pos	= { x = 249.1,	y = -1369.6, z = 10.5 },
		Type = -1
	},

	HospitalInteriorExit2 = { -- Roof entrance
		Pos	= { x = 335.5, y = -1432.0, z = 10.5 },
		Type = 1
	},

	AmbulanceActions = { -- Vestidor
		Pos	= { x = 338.89, y = -592.29, z = 42.50 },
		Type = 1
	},

	VehicleSpawner = {  --  cochera
		Pos	= { x = 292.18, y = -609.76, z = 42.37 },
		Type = 1
	},

	VehicleSpawnPoint = {   -- donde spawnea la ambulancia
		Pos	= { x = 279.49, y = -606.07, z = 43.06 },
		Type = -1
	},

	VehicleDeleter = {    -- remover la ambulancia
		Pos	= { x = 280.41, y = -605.68, z = 43.15 },
		Type = 1
	},

	Pharmacy = {    -- kits
		Pos	= { x = 346.72, y = -587.53, z = 42.50 },
		Type = 1
	},

	ParkingDoorGoOutInside = {
		Pos	= { x = 234.56, y = -1373.77, z = 10.97 },
		Type = 1
	},

	ParkingDoorGoOutOutside = {
		Pos	= { x = 320.98, y = -1478.62, z = 10.81 },
		Type = -1
	},

	ParkingDoorGoInInside = {
		Pos	= { x = 238.64, y = -1368.48, z = 10.53 },
		Type = -1
	},

	ParkingDoorGoInOutside = {
		Pos	= { x = 317.97, y = -1476.13, z = 10.97 },
		Type = 1
	},

	StairsGoTopTop = {
		Pos	= { x = 251.91, y = -1363.3, z = 10.53 },
		Type = -1
	},

	StairsGoTopBottom = {
		Pos	= { x = 237.45, y = -1373.89, z = 10.30 },
		Type = -1
	},

	StairsGoBottomTop = {
		Pos	= { x = 256.58, y = -1357.7, z = 10.30 },
		Type = -1
	},

	StairsGoBottomBottom = {
		Pos	= { x = 235.45, y = -1372.89, z = 10.30 },
		Type = -1
	}

}
