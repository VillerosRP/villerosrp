Config = {}
Config.Locale = 'en'

Config.RequiredCopsRob = 2
Config.RequiredCopsSell = 1

Stores = {
	["jewelry"] = {
		position = { ['x'] = -629.99, ['y'] = -236.542, ['z'] = 38.05 },       
		reward = math.random(300000,300000),
		nameofstore = "Vangelico",
		lastrobbed = 0
	}
}