Config                            = {}
Config.DrawDistance               = 100.0
Config.MarkerType                 = 1
Config.MarkerSize                 = { x = 1.5, y = 1.5, z = 1.0 }
Config.MarkerColor                = { r = 50, g = 50, b = 204 }
Config.EnablePlayerManagement     = true
Config.EnableArmoryManagement     = true
Config.EnableESXIdentity          = true -- only turn this on if you are using esx_identity
Config.EnableNonFreemodePeds      = false -- turn this on if you want custom peds
Config.EnableSocietyOwnedVehicles = false
Config.EnableLicenses             = false
Config.MaxInService               = -1
Config.Locale                     = 'en'

Config.nostraStations = {

  nostra = {

    Blip = {
      Pos     = { x = 425.130, y = -979.558, z = 30.711 },
      Sprite  = 60,
      Display = 4,
      Scale   = 1.2,
      Colour  = 29,
    },

    AuthorizedWeapons = {
      { name = 'WEAPON_PISTOL',     price = 17000 },
      { name = 'WEAPON_FLARE',            price = 3000 },
      { name = 'WEAPON_SWITCHBLADE',      price = 8000 },
	  
    },

	  AuthorizedVehicles = {
		  { name = 'boxville2',  label = 'Camion recluta' },
	  },

    Cloakrooms = {
      { x = 2443.23, y = 4976.97, z = 50.85 },
    },

    Armories = {
      { x = 2490.45, y = 4962.3, z = 45.617 },
    },

    Vehicles = {
      {
        Spawner    = { x = 2437.8, y = 4986.14, z = 45.25 },
        SpawnPoint = { x = 2436.64, y = 4991.73, z = 45.266 },
        Heading    = 90.0,
      }
    },
	
	Helicopters = {
      {
        Spawner    = { x = 666, y = 554.3, z = 46.627 },
        SpawnPoint = { x = 555.21, y = 435.85, z = 456.2 },
        Heading    = 0.0,
      }
    },

    VehicleDeleters = {
      { x = 2429.18, y = 4990.23, z = 45.15 },
    },

    BossActions = {
      { x = 2445.55, y = 4982.86, z = 46.66 }
    },

  },

}
