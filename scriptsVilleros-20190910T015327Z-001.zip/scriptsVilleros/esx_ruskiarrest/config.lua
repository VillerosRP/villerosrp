Config                            	= {}
Config.ArrestDistance				= 3.0       --  Dystans potrzebny miedzy Pedami aby Rozpoczac Funkcje Aresztu