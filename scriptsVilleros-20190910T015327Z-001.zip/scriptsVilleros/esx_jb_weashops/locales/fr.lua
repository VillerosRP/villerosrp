Locales ['fr'] = {

  ['buy_license'] = 'acheter une license ?',
  ['yes'] = 'oui',
  ['no'] = 'non',
  ['buy'] = 'vous avez acheté ~b~1x ',
  ['not_enough_black'] = 'Vous n\'avez ~r~pas assez~s~ d\'argent sale',
  ['not_enough'] = 'vous n\'avez ~r~pas assez~s~ d\'argent',
  ['shop'] = 'magasin',
  ['shop_menu'] = 'appuyez sur ~INPUT_CONTEXT~ pour accéder au magasin.',
  ['map_blip'] = 'armurerie',

}
