Locales ['en'] = {

  ['buy_license'] = 'Comprar permiso ?',
  ['yes'] = 'Si',
  ['no'] = 'No',
  ['buy'] = 'Comprado ',
  ['not_enough_black'] = 'Not enough Dirty Money',
  ['not_enough'] = 'Not enough Clean Money',
  ['shop'] = 'Tienda de armas',
  ['shop_menu'] = 'Presiona ~INPUT_CONTEXT~ para entrar a la tienda',
  ['map_blip'] = 'Tienda de armas',

}
