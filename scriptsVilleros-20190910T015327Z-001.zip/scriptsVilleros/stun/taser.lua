--cresdits Deus
--Edit Sun

--taser old code

local tempo = 16000 --  miliseconds >> 1000 ms

Citizen.CreateThread(function()
	while true do
		Citizen.Wait(0)
		if IsPedBeingStunned(GetPlayerPed(-1)) then
		SetPedMinGroundTimeForStungun(GetPlayerPed(-1), tempo)
		end
	end
end)